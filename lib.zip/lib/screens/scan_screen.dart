import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import '../services/mock_ai_service.dart';

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final service = FirestoreService();
  String? result; // ⭐ ผลจาก AI

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Classify Your Waste',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 16),

              // 📷 กล่องกล้อง (mock)
              Container(
                height: 260,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Center(
                  child: Icon(
                    Icons.camera_alt,
                    size: 80,
                    color: Colors.grey,
                  ),
                ),
              ),

              const SizedBox(height: 24),

              const Text(
                'Results',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),

              const SizedBox(height: 12),

              // ♻️ Result Cards (dynamic)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _ResultCard(
                    title: 'Paper',
                    color: Colors.green,
                    active: result == 'Paper',
                  ),
                  _ResultCard(
                    title: 'Plastic',
                    color: Colors.blue,
                    active: result == 'Plastic',
                  ),
                  _ResultCard(
                    title: 'Organic',
                    color: Colors.brown,
                    active: result == 'Organic',
                  ),
                ],
              ),

              const Spacer(),

              // 🔘 ปุ่ม Scan
              ElevatedButton.icon(
                onPressed: () async {
                  // 🧠 AI Predict
                  final aiResult = MockAIService.predict();

                  setState(() {
                    result = aiResult;
                  });

                  // 💾 Save to Firestore
                  await service.addScan(aiResult);

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('✅ Detected: $aiResult'),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                },
                icon: const Icon(Icons.camera),
                label: const Text('Scan Waste'),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final String title;
  final Color color;
  final bool active;

  const _ResultCard({
    required this.title,
    required this.color,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: 95,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: active ? color.withOpacity(0.25) : color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: active ? Border.all(color: color, width: 2) : null,
      ),
      child: Column(
        children: [
          Icon(Icons.recycling, color: color, size: 30),
          const SizedBox(height: 8),
          Text(
            title,
            style: TextStyle(
              fontSize: 13,
              fontWeight: active ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
