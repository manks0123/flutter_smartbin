import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';


class FirestoreService {
final _db = FirebaseFirestore.instance;
final _uid = FirebaseAuth.instance.currentUser!.uid;


Future<void> addScan(String result) async {
await _db.collection('users').doc(_uid).collection('scans').add({
'result': result,
'createdAt': Timestamp.now(),
});
}


Stream<QuerySnapshot> getScans() {
return _db
.collection('users')
.doc(_uid)
.collection('scans')
.orderBy('createdAt', descending: true)
.snapshots();
}
}